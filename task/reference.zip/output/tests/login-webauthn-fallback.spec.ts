import { test, expect } from "../../input_data/node_modules/playwright/test";
import { createServer, type Server } from "node:http";
import { existsSync, readFileSync, writeFileSync, mkdirSync } from "node:fs";
import path from "node:path";

type Scenario = {
  scenario_id: string;
  locale: string;
  webauthn_mode: string;
  password_attempt: string;
  expected_path: string;
  expected_error_key: string;
  fallback_visible: "yes" | "no";
  expected_focus_after_error: string;
  keyboard_tabs: number;
};

type LocaleBundle = Record<string, string>;

const inputRoot = process.cwd();
const deliveryRoot = path.resolve(inputRoot, "..", "output");
const appRoot = path.join(inputRoot, "app");
const reportRoot = path.join(deliveryRoot, "reports");
const readinessPath = path.join(deliveryRoot, "release_readiness.json");
const scenarios = (JSON.parse(readFileSync(path.join(inputRoot, "scenarios", "auth_scenarios.json"), "utf8")) as { scenarios: Scenario[] }).scenarios;
const localeNames = ["en-US", "zh-CN", "es-ES"];
const localeBundles = Object.fromEntries(localeNames.map((locale) => [
  locale,
  JSON.parse(readFileSync(path.join(appRoot, "locales", `${locale}.json`), "utf8")) as LocaleBundle,
]));
const copyKeys = ["passkey_timeout", "passkey_unsupported", "password_invalid"];

let server: Server;
let origin = "";
const matrixRows: Array<Record<string, unknown>> = [];
const focusRows: Array<Record<string, unknown>> = [];
const localeRows: Array<Record<string, unknown>> = [];

function csvCell(value: unknown): string {
  const text = String(value ?? "");
  return /[",\n]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
}

function writeCsv(fileName: string, headers: string[], rows: Array<Record<string, unknown>>) {
  const lines = [headers.join(","), ...rows.map((row) => headers.map((header) => csvCell(row[header])).join(","))];
  writeFileSync(path.join(reportRoot, fileName), `${lines.join("\n")}\n`, "utf8");
}

function normalizeFocus(testId: string): string {
  return testId ? testId.replaceAll("-", "_") : "none";
}

async function activeTestId(page): Promise<string> {
  return page.evaluate(() => {
    const active = document.activeElement as HTMLElement | null;
    return active?.dataset?.testid ?? active?.tagName?.toLowerCase() ?? "none";
  });
}

async function collectTabSequence(page, count: number): Promise<string> {
  await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur());
  const sequence: string[] = [];
  for (let index = 0; index < count; index += 1) {
    await page.keyboard.press("Tab");
    sequence.push(await activeTestId(page));
  }
  expect(sequence).toHaveLength(count);
  expect(sequence.every((item) => item !== "none")).toBe(true);
  return sequence.join(">");
}

function serveFixture(request, response) {
  const requestUrl = new URL(request.url ?? "/", "http://127.0.0.1");
  const relative = requestUrl.pathname.replace(/^\/app\/?/, "");
  const candidate = path.resolve(appRoot, relative || "login.html");
  if (!candidate.startsWith(`${appRoot}${path.sep}`) || !existsSync(candidate)) {
    response.writeHead(404).end("not found");
    return;
  }
  const contentType = candidate.endsWith(".html") ? "text/html; charset=utf-8"
    : candidate.endsWith(".js") ? "text/javascript; charset=utf-8"
      : candidate.endsWith(".json") ? "application/json; charset=utf-8"
        : "application/octet-stream";
  response.writeHead(200, { "content-type": contentType, "cache-control": "no-store" });
  response.end(readFileSync(candidate));
}

test.describe.configure({ mode: "serial" });

test.beforeAll(async () => {
  mkdirSync(reportRoot, { recursive: true });
  server = createServer(serveFixture);
  await new Promise<void>((resolve, reject) => {
    server.once("error", reject);
    server.listen(0, "127.0.0.1", () => resolve());
  });
  const address = server.address();
  if (!address || typeof address === "string") throw new Error("fixture server did not bind a TCP port");
  origin = `http://127.0.0.1:${address.port}`;
});

for (const scenario of scenarios) {
  test(`scenario ${scenario.scenario_id}`, async ({ page, context }) => {
    if (scenario.webauthn_mode === "virtual_success") {
      await context.credentials.create("127.0.0.1");
      await context.credentials.install();
    }
    if (scenario.webauthn_mode === "unsupported") {
      await page.addInitScript(() => {
        Object.defineProperty(window, "PublicKeyCredential", { value: undefined, configurable: true });
      });
    }

    await page.goto(`${origin}/app/login.html?locale=${scenario.locale}&mode=${scenario.webauthn_mode}`);
    const bundle = localeBundles[scenario.locale];
    await expect(page.locator("html")).toHaveAttribute("lang", scenario.locale);
    await expect(page.getByTestId("title")).toHaveText(bundle.title);
    let observedFocus = "none";
    let observedError = "";

    if (scenario.webauthn_mode === "skip_to_password") {
      await page.getByTestId("password-fallback-button").click();
      await page.getByTestId("email").fill("qa@example.com");
      await page.getByTestId("password").fill("wrong-password");
      await page.getByTestId("submit-password").click();
    } else {
      await page.getByTestId("passkey-button").click();
      if (scenario.password_attempt === "good_password") {
        await expect(page.getByTestId("error")).toHaveText(bundle[scenario.expected_error_key]);
        await expect(page.getByTestId("email")).toBeFocused();
        observedFocus = normalizeFocus(await activeTestId(page));
        await page.getByTestId("email").fill("qa@example.com");
        await page.getByTestId("password").fill("correct-password");
        await page.getByTestId("submit-password").click();
      }
    }

    if (scenario.expected_error_key) {
      if (scenario.password_attempt !== "good_password") {
        await expect(page.getByTestId("error")).toHaveText(bundle[scenario.expected_error_key]);
      }
      observedError = scenario.password_attempt === "good_password"
        ? bundle[scenario.expected_error_key]
        : await page.getByTestId("error").innerText();
    } else {
      await expect(page.getByTestId("error")).toHaveText("");
    }

    if (scenario.fallback_visible === "yes") await expect(page.getByTestId("password-form")).toBeVisible();
    else await expect(page.getByTestId("password-form")).toBeHidden();

    if (scenario.expected_focus_after_error === "email" && scenario.password_attempt !== "good_password") {
      await expect(page.getByTestId("email")).toBeFocused();
      observedFocus = normalizeFocus(await activeTestId(page));
    }
    if (scenario.expected_focus_after_error === "password") {
      await expect(page.getByTestId("password")).toBeFocused();
      observedFocus = normalizeFocus(await activeTestId(page));
    }
    if (scenario.expected_focus_after_error === "passkey_button") {
      await expect(page.getByTestId("passkey-button")).toBeFocused();
      observedFocus = normalizeFocus(await activeTestId(page));
    }
    if (scenario.expected_path === "passkey_success") {
      await expect(page.getByTestId("success")).toHaveText("PASSKEY_OK");
      observedFocus = normalizeFocus(await activeTestId(page));
    }
    if (scenario.expected_path === "password_success_after_fallback") {
      await expect(page.getByTestId("success")).toHaveText("PASSWORD_OK");
      await expect(page.getByTestId("error")).toHaveText("");
    }
    if (scenario.expected_path === "password_error") {
      await expect(page.getByTestId("success")).toHaveText("");
    }

    const tabSequence = await collectTabSequence(page, scenario.keyboard_tabs);
    matrixRows.push({
      ...scenario,
      observed_error_text: observedError,
      observed_focus: observedFocus,
      observed_result: "PASS",
    });
    focusRows.push({
      scenario_id: scenario.scenario_id,
      trigger: scenario.expected_error_key || scenario.expected_path,
      expected_active_element: scenario.expected_focus_after_error,
      observed_active_element: observedFocus,
      fallback_visible: scenario.fallback_visible,
      keyboard_tabs: scenario.keyboard_tabs,
      tab_sequence: tabSequence,
      assertion: "PASS",
    });
  });
}

for (const locale of localeNames) {
  for (const copyKey of copyKeys) {
    test(`locale ${locale} ${copyKey}`, async ({ page }) => {
      const mode = copyKey === "passkey_timeout" ? "timeout"
        : copyKey === "passkey_unsupported" ? "unsupported"
          : "skip_to_password";
      if (mode === "unsupported") {
        await page.addInitScript(() => {
          Object.defineProperty(window, "PublicKeyCredential", { value: undefined, configurable: true });
        });
      }
      await page.goto(`${origin}/app/login.html?locale=${locale}&mode=${mode}`);
      if (copyKey === "password_invalid") {
        await page.getByTestId("password-fallback-button").click();
        await page.getByTestId("submit-password").click();
      } else {
        await page.getByTestId("passkey-button").click();
      }
      const expectedText = localeBundles[locale][copyKey];
      await expect(page.getByTestId("error")).toHaveText(expectedText);
      const observedText = await page.getByTestId("error").innerText();
      localeRows.push({ locale, copy_key: copyKey, expected_text: expectedText, observed_text: observedText, result: "PASS" });
    });
  }
}

test.afterAll(async () => {
  await new Promise<void>((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
  writeCsv("auth_flow_matrix.csv", [
    "scenario_id", "locale", "webauthn_mode", "password_attempt", "expected_path", "expected_error_key",
    "fallback_visible", "expected_focus_after_error", "keyboard_tabs", "observed_error_text", "observed_focus", "observed_result",
  ], matrixRows);
  writeCsv("locale_copy_findings.csv", ["locale", "copy_key", "expected_text", "observed_text", "result"], localeRows);
  writeCsv("focus_recovery.csv", [
    "scenario_id", "trigger", "expected_active_element", "observed_active_element", "fallback_visible", "keyboard_tabs", "tab_sequence", "assertion",
  ], focusRows);

  const blockers = [];
  if (!matrixRows.some((row) => row.expected_path === "passkey_success" && row.observed_result === "PASS")) blockers.push("passkey_success_not_observed");
  if (!matrixRows.some((row) => row.webauthn_mode === "unsupported" && row.observed_result === "PASS")) blockers.push("unsupported_route_not_observed");
  if (!localeRows.every((row) => row.expected_text === row.observed_text)) blockers.push("locale_copy_mismatch");
  if (!focusRows.every((row) => row.expected_active_element === "none" || row.expected_active_element === row.observed_active_element)) blockers.push("focus_recovery_mismatch");
  const readiness = {
    release_decision: blockers.length === 0 ? "ready" : "hold",
    reviewed_scenarios: matrixRows.length,
    locales: localeNames,
    passkey_success_observed: matrixRows.some((row) => row.expected_path === "passkey_success" && row.observed_result === "PASS"),
    password_fallback_routes: matrixRows.filter((row) => row.fallback_visible === "yes").length,
    localized_copy_observations: localeRows.length,
    focus_observations: focusRows.length,
    blockers,
  };
  expect(readiness.release_decision).toBe("ready");
  writeFileSync(readinessPath, `${JSON.stringify(readiness, null, 2)}\n`, "utf8");
});
