# 多语言登录页发布复核

app目录提供本地登录页、页面脚本与三套语言包，scenarios/auth_scenarios.json提供通行密钥成功、降级和密码恢复等认证路径，starter目录提供待完成的Playwright脚本。页面、语言包和场景文件都会被脚本读取。

将完成版测试交付到output/tests/login-webauthn-fallback.spec.ts，然后在input_data目录执行：

    npm run process

入口运行完成脚本，把页面中观察到的认证路径、本地化文案和焦点恢复写入三份CSV，并生成release_readiness.json供发布经理判断是否放量。先按package.json安装Playwright依赖和匹配的Chromium。
