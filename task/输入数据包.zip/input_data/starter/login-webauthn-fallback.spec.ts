import { test, expect } from "../../input_data/node_modules/playwright/test";

test("多语言登录发布复核", async ({ page }) => {
  await page.setContent("<main><h1>登录发布复核脚本尚未完成</h1></main>");
  await expect(page.locator("h1")).toHaveText("请依据任务说明完成浏览器观察和业务交付");
});
