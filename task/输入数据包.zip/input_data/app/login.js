const params = new URLSearchParams(location.search);
const locale = params.get("locale") || "en-US";
const mode = params.get("mode") || "virtual_success";
let bundle;
const $ = (id) => document.querySelector('[data-testid="' + id + '"]');
async function loadBundle() {
  bundle = await fetch('./locales/' + locale + '.json').then((r) => r.json());
  document.documentElement.lang = locale;
  $('title').textContent = bundle.title;
  $('passkey-button').textContent = bundle.passkey;
  $('password-fallback-button').textContent = bundle.password;
  $('email-label').textContent = bundle.email;
  $('password-label').textContent = bundle.passwordLabel;
  $('submit-password').textContent = bundle.submit;
}
function showError(key, focusTarget) {
  $('error').textContent = bundle[key];
  $('password-form').hidden = false;
  if (focusTarget === 'email') $('email').focus();
  if (focusTarget === 'password') $('password').focus();
  if (focusTarget === 'passkey_button') $('passkey-button').focus();
}
async function onPasskey() {
  if (mode === 'unsupported' || !window.PublicKeyCredential) return showError('passkey_unsupported', 'email');
  if (mode === 'timeout' || mode === 'timeout_then_good_password') return showError('passkey_timeout', 'email');
  if (mode === 'cancelled') return showError('passkey_cancelled', 'passkey_button');
  try {
    const credential = await navigator.credentials.get({
      publicKey: {
        challenge: new Uint8Array(32).fill(7),
        rpId: location.hostname,
        timeout: 3000,
        userVerification: 'required'
      }
    });
    if (!credential) throw new Error('missing WebAuthn credential');
    $('success').textContent = 'PASSKEY_OK';
  } catch (error) {
    showError('passkey_cancelled', 'passkey_button');
  }
}
function onPassword(event) {
  event.preventDefault();
  if (mode === 'skip_to_password') return showError('password_invalid', 'password');
  $('error').textContent = '';
  $('success').textContent = 'PASSWORD_OK';
}
loadBundle().then(() => {
  $('passkey-button').addEventListener('click', onPasskey);
  $('password-fallback-button').addEventListener('click', () => { $('password-form').hidden = false; $('email').focus(); });
  $('password-form').addEventListener('submit', onPassword);
});
