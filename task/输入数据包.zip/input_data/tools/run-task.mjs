import fs from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const inputRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const deliveryRoot = path.resolve(inputRoot, "..", "output");
const specPath = path.join(deliveryRoot, "tests", "login-webauthn-fallback.spec.ts");
const reportRoot = path.join(deliveryRoot, "reports");
const readinessPath = path.join(deliveryRoot, "release_readiness.json");
const cliPath = path.join(inputRoot, "node_modules", "playwright", "cli.js");
const configPath = path.join(inputRoot, "playwright.config.cjs");

fs.rmSync(deliveryRoot, { recursive: true, force: true });
const candidateSpec = path.join(inputRoot, "starter", "login-webauthn-fallback.spec.ts");
if (!fs.existsSync(candidateSpec) || !fs.existsSync(cliPath)) {
  console.error("缺少完成脚本或Playwright入口");
  process.exit(2);
}
const source = fs.readFileSync(candidateSpec, "utf8");
if (/尚未完成|starter placeholder|请补全|\bTODO\b/.test(source)) {
  console.error("交付测试仍未完成");
  process.exit(2);
}
fs.mkdirSync(path.dirname(specPath), { recursive: true });
fs.writeFileSync(specPath, source, "utf8");

const result = spawnSync(process.execPath, [cliPath, "test", path.basename(specPath), "--config", configPath, "--workers=1", "--reporter=line"], {
  cwd: inputRoot,
  stdio: "inherit",
  env: { ...process.env },
  timeout: 120000
});
if (result.error || result.status !== 0) {
  fs.rmSync(deliveryRoot, { recursive: true, force: true });
  if (result.error) console.error(result.error.message);
  process.exit(result.status ?? 1);
}
for (const relative of ["reports/auth_flow_matrix.csv", "reports/locale_copy_findings.csv", "reports/focus_recovery.csv", "release_readiness.json"]) {
  if (!fs.existsSync(path.join(deliveryRoot, relative))) {
    console.error(`缺少浏览器运行交付：${relative}`);
    process.exit(1);
  }
}
