const os = require("node:os");
const path = require("node:path");

module.exports = {
  testDir: path.resolve(__dirname, "..", "output", "tests"),
  outputDir: path.join(os.tmpdir(), "login-webauthn-review-results"),
  timeout: 20000,
  workers: 1,
  fullyParallel: false,
  reporter: "line",
  use: {
    browserName: "chromium",
    headless: true,
    trace: "off",
    screenshot: "off",
    video: "off"
  }
};
